"""Download daily NSE stock data from Yahoo Finance.

Note: yfinance is a third-party data source, not an official NSE feed.
The end date is exclusive; using tomorrow includes the latest available session.
"""
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import yfinance as yf

TICKERS = [
    "RELIANCE.NS",
    "TCS.NS",
    "INFY.NS",
    "HDFCBANK.NS",
    "ICICIBANK.NS",
]
START_DATE = "2025-01-01"
END_DATE = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
DATA_DIR = Path("data")


def download_stock_data():
    DATA_DIR.mkdir(exist_ok=True)
    all_data = []

    for ticker in TICKERS:
        print(f"Downloading {ticker} from {START_DATE} to {END_DATE} ...")
        try:
            data = yf.download(
                ticker, start=START_DATE, end=END_DATE,
                interval="1d", auto_adjust=False,
                progress=False, threads=False
            )
            if data is None or data.empty:
                print(f"WARNING: No data returned for {ticker}.")
                continue

            if isinstance(data.columns, pd.MultiIndex):
                data.columns = data.columns.get_level_values(0)

            required = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
            missing = [c for c in required if c not in data.columns]
            if missing:
                print(f"WARNING: {ticker} is missing columns: {missing}")
                continue

            data = data[required].reset_index()
            data["Stock"] = ticker
            data["Date"] = pd.to_datetime(data["Date"]).dt.tz_localize(None)
            all_data.append(data)
            print(f"  Retrieved {len(data)} rows.")
        except Exception as exc:
            print(f"ERROR downloading {ticker}: {exc}")

    if not all_data:
        raise RuntimeError(
            "No stock data was downloaded. Check internet access, ticker symbols, "
            "and Yahoo Finance availability."
        )

    final_data = pd.concat(all_data, ignore_index=True)
    final_data = final_data.sort_values(["Stock", "Date"]).reset_index(drop=True)
    final_data.to_csv(DATA_DIR / "stock_data.csv", index=False)

    counts = final_data.groupby("Stock").size()
    print("\nDownload summary:")
    print(counts.to_string())
    print(f"\nTotal rows: {len(final_data)}")
    print(f"Actual date range: {final_data['Date'].min().date()} to "
          f"{final_data['Date'].max().date()}")
    return final_data


if __name__ == "__main__":
    download_stock_data()
