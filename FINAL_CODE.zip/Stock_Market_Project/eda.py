"""Exploratory data analysis and statistical summaries."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

DATA_PATH = Path("data/processed_stock_data.csv")
OUT = Path("outputs")


def perform_eda():
    if not DATA_PATH.exists():
        raise FileNotFoundError("Run preprocessing.py before EDA.")
    OUT.mkdir(exist_ok=True)
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])
    sns.set_theme(style="whitegrid")

    print("\n========== DATASET DESCRIPTION ==========")
    print("Shape:", df.shape)
    print("\nData types:\n", df.dtypes)
    print("\nStatistical summary:\n", df.describe(include="all").transpose())
    print("\nMissing values:\n", df.isnull().sum())
    print("\nDuplicate rows:", df.duplicated().sum())
    print("\nTarget distribution:\n", df["Target"].value_counts())

    # Descriptive statistics for numeric variables and by-stock summaries.
    df.describe().transpose().to_csv(OUT / "statistical_summary.csv")
    df.groupby("Stock")["Close"].agg(
        ["count", "mean", "median", "std", "min", "max"]
    ).to_csv(OUT / "stock_descriptive_statistics.csv")

    # 1. Closing-price line charts.
    for stock, group in df.groupby("Stock"):
        plt.figure(figsize=(10, 5))
        plt.plot(group["Date"], group["Close"], label="Close")
        plt.title(f"{stock} Closing Price")
        plt.xlabel("Date")
        plt.ylabel("Price (INR)")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(OUT / f"{stock.replace('.', '_')}_closing_price.png", dpi=150)
        plt.close()

    # 2. Histogram.
    plt.figure(figsize=(8, 5))
    plt.hist(df["Daily_Return"].dropna(), bins=40)
    plt.title("Distribution of Daily Returns")
    plt.xlabel("Daily return")
    plt.ylabel("Frequency")
    plt.tight_layout()
    plt.savefig(OUT / "daily_return_histogram.png", dpi=150)
    plt.close()

    # 3. Scatter plot.
    plt.figure(figsize=(8, 5))
    plt.scatter(df["Volume"], df["Daily_Return"], alpha=0.45)
    plt.title("Trading Volume vs Daily Return")
    plt.xlabel("Trading volume")
    plt.ylabel("Daily return")
    plt.tight_layout()
    plt.savefig(OUT / "volume_vs_return_scatter.png", dpi=150)
    plt.close()

    # 4. Moving average chart for one example stock.
    example = df["Stock"].iloc[0]
    sample = df[df["Stock"] == example]
    plt.figure(figsize=(11, 5))
    plt.plot(sample["Date"], sample["Close"], label="Close")
    plt.plot(sample["Date"], sample["MA_5"], label="5-day MA")
    plt.plot(sample["Date"], sample["MA_10"], label="10-day MA")
    plt.title(f"{example}: Closing Price and Moving Averages")
    plt.xlabel("Date")
    plt.ylabel("Price (INR)")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT / "moving_average_analysis.png", dpi=150)
    plt.close()

    # 5. Correlation heatmap.
    numeric = df.select_dtypes(include="number")
    corr = numeric.corr()
    plt.figure(figsize=(12, 9))
    sns.heatmap(corr, cmap="coolwarm", center=0, annot=False)
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(OUT / "correlation_heatmap.png", dpi=150)
    plt.close()

    # 6. Bar chart: number of observations per stock.
    plt.figure(figsize=(9, 5))
    df["Stock"].value_counts().plot(kind="bar")
    plt.title("Number of Records per Stock")
    plt.xlabel("Stock")
    plt.ylabel("Number of records")
    plt.xticks(rotation=35)
    plt.tight_layout()
    plt.savefig(OUT / "records_per_stock_bar.png", dpi=150)
    plt.close()

    print(f"\nEDA complete. Tables and graphs saved in {OUT.resolve()}")


if __name__ == "__main__":
    perform_eda()
