# Stock Market Trend Analysis & Prediction — Project Documentation

## 1. Problem Understanding (Unit I)

### Problem statement
The project studies historical daily market information for selected Indian stocks and develops supervised machine-learning classification models to estimate whether the next observed trading session's closing price will be higher than the current session's closing price.

### Business objective
The objective is to explore whether historical price and volume-derived indicators contain patterns that help classify the next trading session's direction. The models are compared using classification metrics. The output is an academic analytical aid, not a guaranteed forecast or investment recommendation.

### CRISP-DM process
1. **Business understanding:** Define the stock-direction classification problem and the project's analytical objective.
2. **Data understanding:** Obtain historical OHLCV data, inspect columns, data types, coverage, missing values and duplicates.
3. **Data preparation:** Clean invalid records, calculate returns, moving averages, volume changes and volatility, and create the next-session direction label.
4. **Modelling:** Train Logistic Regression, K-Nearest Neighbors and Decision Tree classifiers.
5. **Evaluation:** Use a chronological holdout period, accuracy, precision, recall, F1-score and confusion matrices; compare the models.
6. **Deployment:** Present historical analysis and evaluation results in a Streamlit dashboard.

## 2. Data Understanding (Unit III)

### Dataset description
The project downloads daily observations for five NSE ticker symbols:
- RELIANCE.NS — Reliance Industries
- TCS.NS — Tata Consultancy Services
- INFY.NS — Infosys
- HDFCBANK.NS — HDFC Bank
- ICICIBANK.NS — ICICI Bank

The requested start date is 1 January 2025. The download end date is set dynamically to the day after execution because Yahoo Finance's end date is exclusive. The actual retrieved date range and record count are printed and saved by the code.

### Data types
- Date: temporal data
- Stock: categorical data
- Open, High, Low, Close, Adj Close: numerical continuous price data
- Volume: numerical count/quantity data
- Derived returns, moving averages and volatility: numerical features
- Target: binary categorical class (1=UP, 0=DOWN/SAME)

### Data source
The implementation uses the `yfinance` Python package to retrieve Yahoo Finance historical data. This is a third-party source and is not an official NSE data feed. The actual downloaded range and availability must be checked after each run.

### Data quality
The code generates:
- `outputs/data_quality_report.csv`: data type, missing count, missing percentage and unique count by column.
- `outputs/data_quality_summary.csv`: initial rows, duplicates, stock count and date coverage.
- `outputs/cleaning_summary.csv`: rows retained after cleaning, stocks retained, date coverage and class counts.

The cleaning procedure removes duplicate rows, missing required fields, non-positive OHLC prices, negative volume and rows that cannot support the rolling features or next-session target. The reports are generated from the actual downloaded dataset; do not invent quality figures in the report.

## 3. Exploratory Data Analysis (Unit III)

The EDA script produces:
- Closing-price line charts for each stock
- Daily-return histogram
- Trading-volume versus daily-return scatter plot
- Closing-price and moving-average chart
- Correlation heatmap
- Bar chart of record counts by stock

It also prints dataset dimensions, data types, descriptive statistics, missing-value counts, duplicate count and target-class distribution. Numerical and per-stock descriptive summaries are saved in the outputs folder.

## 4. Feature Engineering (Unit IV)

The selected model features are:
1. **Daily_Return:** percentage change in closing price from the previous observed session for that stock.
2. **Price_Range:** high price minus low price for the session.
3. **MA_5:** five-session moving average of closing price.
4. **MA_10:** ten-session moving average of closing price.
5. **Previous_Return:** previous observed session's daily return.
6. **Volume_Change:** percentage change in trading volume.
7. **Volatility_5:** rolling five-session standard deviation of daily returns.

These features were selected because they represent price momentum, intraday price range, short-term trend, previous movement, trading activity and recent variability. The Stock category is also included so the model can distinguish between the selected companies.

Feature transformation: numeric features are imputed using the training-fold median and standardised using `StandardScaler`. The stock category is imputed using the most frequent category and one-hot encoded. These transformations are fitted inside the model pipeline, preventing validation/test observations from influencing fitted preprocessing parameters.

PCA is optional in the supplied instructions and is not required for this version.

## 5. Machine Learning Model (Unit V)

The project uses supervised binary classification:
- Logistic Regression
- K-Nearest Neighbors (KNN)
- Decision Tree

Target definition:
- 1 (UP): next observed trading session's Close is greater than the current Close.
- 0 (DOWN/SAME): next observed trading session's Close is less than or equal to the current Close.

The next close is used only to create the label; it is not included as a model input feature.

## 6. Model Evaluation (Unit V)

The data is split chronologically by unique trading dates: earlier dates form the training set and later dates form the held-out test set. Records from the same date are kept together. Hyperparameter tuning uses expanding chronological validation folds within the training period only.

Metrics:
- Accuracy: fraction of all predictions that are correct.
- Precision: proportion of predicted UP cases that are actually UP.
- Recall: proportion of actual UP cases correctly identified.
- F1-score: harmonic mean of precision and recall.
- Confusion matrix: counts of correct and incorrect predictions by class.

The models are compared in `outputs/model_results.csv`. The confusion matrix for each classifier is saved separately. Actual metric values must be taken from the generated output files after running the project; do not claim a model is best before running the code.

## 7. Results and Insights

After running the pipeline, use the generated metrics, EDA charts and data-quality reports to discuss:
- Which stock has the most/least observations in the downloaded period.
- How closing prices and daily returns vary across the selected stocks.
- Whether volume and daily returns show an apparent relationship.
- Which model performs best on the held-out chronological test set.
- What the confusion matrices reveal about UP and DOWN/SAME classification errors.
- Limitations such as short historical coverage, market volatility, third-party data source, and the fact that historical patterns may not persist.

## Reproducibility and execution

Install dependencies:
```bash
pip install -r requirements.txt
```

Run the complete pipeline:
```bash
python main.py
```

Launch the dashboard after the pipeline completes:
```bash
streamlit run dashboard.py
```

The pipeline creates the `data`, `models`, and `outputs` directories as needed.

## Important limitations

This project is for academic learning and is not investment advice. It does not establish that the models can consistently predict future market direction. Yahoo Finance data availability and adjustments can change. Confirm data completeness and any applicable data-use terms before submission. The final report must describe the actual results from the run, not assumed results.
