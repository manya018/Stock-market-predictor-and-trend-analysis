"""Leakage-aware chronological hyperparameter tuning for all classifiers."""
import numpy as np
import pandas as pd

from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

NUMERIC_FEATURES = [
    "Daily_Return", "Price_Range", "MA_5", "MA_10",
    "Previous_Return", "Volume_Change", "Volatility_5"
]
FEATURES = NUMERIC_FEATURES + ["Stock"]


def make_date_grouped_splits(train_df, n_splits=5):
    """Create expanding-window folds; all records from a date stay together."""
    dates = np.array(sorted(train_df["Date"].drop_duplicates()))
    if len(dates) < n_splits + 2:
        raise ValueError("Not enough unique dates for time-series cross-validation.")

    initial = max(5, len(dates) // (n_splits + 1))
    remaining = len(dates) - initial
    fold_size = max(1, remaining // n_splits)
    splits = []

    for fold in range(n_splits):
        train_end = initial + fold * fold_size
        valid_end = len(dates) if fold == n_splits - 1 else min(
            len(dates), train_end + fold_size
        )
        train_dates = set(dates[:train_end])
        valid_dates = set(dates[train_end:valid_end])
        train_idx = np.flatnonzero(train_df["Date"].isin(train_dates).to_numpy())
        valid_idx = np.flatnonzero(train_df["Date"].isin(valid_dates).to_numpy())
        if len(train_idx) and len(valid_idx):
            splits.append((train_idx, valid_idx))

    if len(splits) < 2:
        raise ValueError("Could not create at least two valid chronological folds.")
    return splits


def build_pipeline(estimator):
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    prep = ColumnTransformer([
        ("numeric", numeric_pipe, NUMERIC_FEATURES),
        ("categorical", categorical_pipe, ["Stock"]),
    ])
    return Pipeline([("preprocessor", prep), ("classifier", estimator)])


def tune_models(train_df):
    """Tune Logistic Regression, KNN and Decision Tree using training data only."""
    train_df = train_df.reset_index(drop=True)
    X_train = train_df[FEATURES]
    y_train = train_df["Target"]
    cv = make_date_grouped_splits(train_df, n_splits=5)

    model_specs = {
        "Logistic Regression": (
            LogisticRegression(max_iter=2000, class_weight="balanced"),
            {
                "classifier__C": [0.01, 0.1, 1, 10],
                "classifier__solver": ["liblinear"],
            },
        ),
        "KNN": (
            KNeighborsClassifier(),
            {
                "classifier__n_neighbors": [3, 5, 7, 9, 11],
                "classifier__weights": ["uniform", "distance"],
                "classifier__metric": ["euclidean", "manhattan"],
            },
        ),
        "Decision Tree": (
            DecisionTreeClassifier(random_state=42, class_weight="balanced"),
            {
                "classifier__max_depth": [3, 5, 7, 10, None],
                "classifier__min_samples_split": [2, 5, 10],
                "classifier__min_samples_leaf": [1, 2, 5],
            },
        ),
    }

    best_models, tuning_rows = {}, []
    for name, (estimator, grid) in model_specs.items():
        print(f"\nTuning {name} ...")
        search = GridSearchCV(
            build_pipeline(estimator),
            param_grid=grid,
            scoring="f1",
            cv=cv,
            n_jobs=1,
            refit=True,
            error_score="raise",
        )
        search.fit(X_train, y_train)
        best_models[name] = search.best_estimator_
        tuning_rows.append({
            "Model": name,
            "Best_CV_F1": search.best_score_,
            "Best_Parameters": str(search.best_params_),
        })
        print("Best parameters:", search.best_params_)
        print("Best chronological CV F1:", round(search.best_score_, 4))

    pd.DataFrame(tuning_rows).to_csv("outputs/tuning_results.csv", index=False)
    return best_models


if __name__ == "__main__":
    df = pd.read_csv("data/processed_stock_data.csv", parse_dates=["Date"])
    dates = sorted(df["Date"].unique())
    cutoff = dates[int(len(dates) * 0.8)]
    training = df[df["Date"] < cutoff].copy()
    tune_models(training)
