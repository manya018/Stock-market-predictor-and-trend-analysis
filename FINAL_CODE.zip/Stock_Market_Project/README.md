# Indian Stock Market Trend Analysis & Prediction

This is the updated modular version of the original group project. It retains the original five stocks and three supervised classifiers while addressing the academic requirements in the project instruction sheet.

## Run
```bash
pip install -r requirements.txt
python main.py
streamlit run dashboard.py
```

Run `main.py` first. It downloads data, assesses quality, preprocesses, performs EDA, tunes models and evaluates them.

## Project files
- `download_data.py`: data acquisition
- `preprocessing.py`: data quality, cleaning and feature engineering
- `eda.py`: descriptive statistics and visualisations
- `tune_models.py`: chronological hyperparameter tuning
- `train_models.py`: training, held-out evaluation and saving models
- `dashboard.py`: Streamlit dashboard
- `main.py`: complete workflow
- `PROJECT_DOCUMENTATION.md`: academic methodology and report content guide

## Outputs
Generated CSV summaries, charts, predictions, confusion matrices and model files are saved in `outputs/`, `data/` and `models/`.

The project uses Yahoo Finance via yfinance, a third-party data source rather than an official NSE data feed. It is an academic project, not investment advice. Check the actual date range and data quality after downloading.
