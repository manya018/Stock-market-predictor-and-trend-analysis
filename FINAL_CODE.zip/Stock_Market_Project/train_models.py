"""Chronological training, held-out evaluation and model persistence."""
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report, confusion_matrix, roc_auc_score
)
from tune_models import tune_models, FEATURES

OUT = Path("outputs")
MODEL_DIR = Path("models")


def calculate_metrics(y_true, predictions, probabilities=None):
    result = {
        "Accuracy": accuracy_score(y_true, predictions),
        "Precision": precision_score(y_true, predictions, zero_division=0),
        "Recall": recall_score(y_true, predictions, zero_division=0),
        "F1 Score": f1_score(y_true, predictions, zero_division=0),
    }
    result["ROC_AUC"] = (
        roc_auc_score(y_true, probabilities)
        if probabilities is not None and len(np.unique(y_true)) == 2
        else np.nan
    )
    return result


def train_models():
    path = Path("data/processed_stock_data.csv")
    if not path.exists():
        raise FileNotFoundError("Run preprocessing.py first.")

    df = pd.read_csv(path, parse_dates=["Date"])
    df = df.sort_values(["Date", "Stock"]).reset_index(drop=True)
    dates = np.array(sorted(df["Date"].drop_duplicates()))
    if len(dates) < 20:
        raise ValueError("Not enough unique dates for reliable chronological evaluation.")

    split_index = int(len(dates) * 0.80)
    cutoff = dates[split_index]
    train_df = df[df["Date"] < cutoff].copy().reset_index(drop=True)
    test_df = df[df["Date"] >= cutoff].copy().reset_index(drop=True)

    print("\n========== CHRONOLOGICAL TRAIN/TEST SPLIT ==========")
    print(f"Training dates: {train_df['Date'].min().date()} to {train_df['Date'].max().date()}")
    print(f"Testing dates:  {test_df['Date'].min().date()} to {test_df['Date'].max().date()}")
    print("Training rows:", len(train_df), "| Testing rows:", len(test_df))

    # Hyperparameter search sees only the training period.
    best_models = tune_models(train_df)
    X_test = test_df[FEATURES]
    y_test = test_df["Target"]

    rows, prediction_tables = [], []
    OUT.mkdir(exist_ok=True)
    MODEL_DIR.mkdir(exist_ok=True)
    sns.set_theme(style="whitegrid")

    for name, model in best_models.items():
        predictions = model.predict(X_test)
        probabilities = model.predict_proba(X_test)[:, 1]
        metrics = calculate_metrics(y_test, predictions, probabilities)
        metrics["Model"] = name
        rows.append(metrics)

        print(f"\n========== {name} ==========")
        print(classification_report(
            y_test, predictions, labels=[0, 1],
            target_names=["DOWN_OR_SAME", "UP"], zero_division=0
        ))

        cm = confusion_matrix(y_test, predictions, labels=[0, 1])
        plt.figure(figsize=(5, 4))
        sns.heatmap(
            cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["DOWN/SAME", "UP"],
            yticklabels=["DOWN/SAME", "UP"]
        )
        plt.title(f"{name} - Confusion Matrix")
        plt.xlabel("Predicted")
        plt.ylabel("Actual")
        plt.tight_layout()
        safe = name.lower().replace(" ", "_")
        plt.savefig(OUT / f"{safe}_confusion_matrix.png", dpi=150)
        plt.close()

        table = test_df[["Date", "Stock", "Close", "Target"]].copy()
        table["Model"] = name
        table["Predicted"] = predictions
        table["Probability_UP"] = probabilities
        prediction_tables.append(table)

        joblib.dump(model, MODEL_DIR / f"{safe}_pipeline.joblib")

    results = pd.DataFrame(rows).set_index("Model")
    results.to_csv("data/model_results.csv")
    results.to_csv(OUT / "model_results.csv")

    all_predictions = pd.concat(prediction_tables, ignore_index=True)
    all_predictions.to_csv(OUT / "test_predictions.csv", index=False)

    results[["Accuracy", "Precision", "Recall", "F1 Score"]].plot(
        kind="bar", figsize=(10, 5), ylim=(0, 1)
    )
    plt.title("Model Performance Comparison")
    plt.ylabel("Score")
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(OUT / "model_performance_comparison.png", dpi=150)
    plt.close()

    best_name = results["F1 Score"].idxmax()
    (OUT / "best_model.txt").write_text(
        f"Best model by held-out test F1-score: {best_name}\n"
        f"{results.loc[best_name].to_string()}\n",
        encoding="utf-8"
    )
    print("\n========== MODEL RESULTS ==========")
    print(results.round(4))
    print("\nBest model by held-out test F1-score:", best_name)
    print("All models and results saved.")
    return results


if __name__ == "__main__":
    train_models()
