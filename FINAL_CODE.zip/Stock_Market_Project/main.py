"""Run the complete stock-market machine-learning project using a static CSV dataset."""

from pathlib import Path

from preprocessing import preprocess_data
from eda import perform_eda
from train_models import train_models


DATA_PATH = Path("data/stock_data.csv")


def main():

    print("\nSTOCK MARKET TREND ANALYSIS & PREDICTION PROJECT")
    print("=" * 55)

    # ---------------------------------------------------------
    # CHECK DATASET
    # ---------------------------------------------------------

    if not DATA_PATH.exists():
        raise FileNotFoundError(
            "\ndata/stock_data.csv not found.\n"
            "Place the stock_data.csv dataset inside the data folder."
        )

    print("\nDataset found:")
    print(DATA_PATH)

    # ---------------------------------------------------------
    # STEP 1 - PREPROCESSING
    # ---------------------------------------------------------

    print("\nStep 1/3: Data quality assessment and preprocessing ...")

    preprocess_data()

    # ---------------------------------------------------------
    # STEP 2 - EXPLORATORY DATA ANALYSIS
    # ---------------------------------------------------------

    print("\nStep 2/3: Exploratory Data Analysis ...")

    perform_eda()

    # ---------------------------------------------------------
    # STEP 3 - MACHINE LEARNING
    # ---------------------------------------------------------

    print(
        "\nStep 3/3: Hyperparameter tuning, "
        "model training and evaluation ..."
    )

    train_models()

    # ---------------------------------------------------------
    # COMPLETE
    # ---------------------------------------------------------

    print("\n" + "=" * 55)
    print("PROJECT PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 55)

    print("\nLaunch the dashboard using:")
    print("python -m streamlit run dashboard.py")


if __name__ == "__main__":
    main()