"""Interactive Streamlit dashboard for Stock Market Trend Analysis & Prediction."""

from pathlib import Path

import pandas as pd
import streamlit as st


# ============================================================
# PATHS
# ============================================================

DATA = Path("data")
OUT = Path("outputs")


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="Stock Market Prediction",
    page_icon=None,
    layout="wide"
)

st.title("Stock Market Trend Analysis & Prediction")
st.caption(
    "Indian Stock Market | Historical Analysis & Machine Learning Prediction"
)


# ============================================================
# LOAD DATA
# ============================================================

processed_path = DATA / "processed_stock_data.csv"

if not processed_path.exists():
    st.error("Processed data not found. Run `python main.py` first.")
    st.stop()

df = pd.read_csv(processed_path, parse_dates=["Date"])


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.header("Dashboard Filters")

stocks = sorted(df["Stock"].unique())

selected_stock = st.sidebar.selectbox(
    "Select Stock",
    stocks
)

stock_data = (
    df[df["Stock"] == selected_stock]
    .sort_values("Date")
    .copy()
)

st.sidebar.write("### Dataset Information")
st.sidebar.write("Records:", len(stock_data))
st.sidebar.write(
    "From:",
    stock_data["Date"].min().strftime("%d %b %Y")
)
st.sidebar.write(
    "To:",
    stock_data["Date"].max().strftime("%d %b %Y")
)


# ============================================================
# STOCK OVERVIEW
# ============================================================

st.header(f"{selected_stock} Overview")

c1, c2, c3, c4 = st.columns(4)

c1.metric(
    "Latest Close",
    f"₹{stock_data['Close'].iloc[-1]:,.2f}"
)

c2.metric(
    "Highest Price",
    f"₹{stock_data['High'].max():,.2f}"
)

c3.metric(
    "Lowest Price",
    f"₹{stock_data['Low'].min():,.2f}"
)

c4.metric(
    "Average Volume",
    f"{stock_data['Volume'].mean():,.0f}"
)


# ============================================================
# GRAPH 1 — CLOSING PRICE
# ============================================================

st.subheader("1. Closing Price Trend")

st.line_chart(
    stock_data.set_index("Date")[["Close"]],
    use_container_width=True
)

st.caption(
    "Shows how the stock's closing price changes over the selected time period."
)


# ============================================================
# GRAPH 2 — MOVING AVERAGES
# ============================================================

st.subheader("2. Closing Price vs Moving Averages")

moving_average_data = stock_data.set_index("Date")[
    ["Close", "MA_5", "MA_10"]
]

st.line_chart(
    moving_average_data,
    use_container_width=True
)

st.caption(
    "MA_5 represents the 5-session moving average and MA_10 represents "
    "the 10-session moving average. They help identify short-term trends."
)


# ============================================================
# SIDE-BY-SIDE GRAPHS
# ============================================================

left, right = st.columns(2)


# ============================================================
# GRAPH 3 — TRADING VOLUME
# ============================================================

with left:

    st.subheader("3. Trading Volume")

    st.bar_chart(
        stock_data.set_index("Date")[["Volume"]],
        use_container_width=True
    )

    st.caption(
        "Shows the amount of trading activity for the selected stock."
    )


# ============================================================
# GRAPH 4 — DAILY RETURNS
# ============================================================

with right:

    st.subheader("4. Daily Returns")

    st.line_chart(
        stock_data.set_index("Date")[["Daily_Return"]],
        use_container_width=True
    )

    st.caption(
        "Shows the percentage change in closing price from the previous "
        "trading session."
    )


# ============================================================
# GRAPH 5 — PRICE RANGE
# ============================================================

left, right = st.columns(2)

with left:

    st.subheader("5. Daily Price Range")

    st.line_chart(
        stock_data.set_index("Date")[["Price_Range"]],
        use_container_width=True
    )

    st.caption(
        "Price Range = High Price − Low Price. "
        "A larger value indicates greater intraday movement."
    )


# ============================================================
# GRAPH 6 — VOLATILITY
# ============================================================

with right:

    st.subheader("6. 5-Session Volatility")

    st.line_chart(
        stock_data.set_index("Date")[["Volatility_5"]],
        use_container_width=True
    )

    st.caption(
        "Volatility measures how strongly returns have fluctuated "
        "during the recent five trading sessions."
    )


# ============================================================
# GRAPH 7 — UP VS DOWN/SAME DISTRIBUTION
# ============================================================

st.subheader("7. Target Class Distribution")

target_counts = (
    stock_data["Target"]
    .map({
        0: "DOWN / SAME",
        1: "UP"
    })
    .value_counts()
)

st.bar_chart(target_counts)

st.caption(
    "UP means the next observed trading session closed higher. "
    "DOWN/SAME means the next session closed at or below the current close."
)


# ============================================================
# GRAPH 8 — VOLUME CHANGE
# ============================================================

st.subheader("8. Trading Volume Change")

st.line_chart(
    stock_data.set_index("Date")[["Volume_Change"]],
    use_container_width=True
)

st.caption(
    "Shows the percentage change in trading volume compared with "
    "the previous observed session."
)


# ============================================================
# MODEL PERFORMANCE
# ============================================================

st.header("Machine Learning Model Evaluation")

metrics_path = OUT / "model_results.csv"

if metrics_path.exists():

    metrics = pd.read_csv(
        metrics_path,
        index_col=0
    )

    st.subheader("Model Performance Table")

    st.dataframe(
        metrics.style.format("{:.3f}"),
        use_container_width=True
    )


    # ========================================================
    # GRAPH 9 — MODEL PERFORMANCE
    # ========================================================

    st.subheader("9. Model Performance Comparison")

    available_metrics = [
        column
        for column in [
            "Accuracy",
            "Precision",
            "Recall",
            "F1 Score"
        ]
        if column in metrics.columns
    ]

    st.bar_chart(
        metrics[available_metrics],
        use_container_width=True
    )

    st.caption(
        "Compares Logistic Regression, KNN and Decision Tree "
        "using classification evaluation metrics."
    )


    # ========================================================
    # BEST MODEL
    # ========================================================

    if "F1 Score" in metrics.columns:

        best_model = metrics["F1 Score"].idxmax()
        best_f1 = metrics.loc[best_model, "F1 Score"]

        st.success(
            f"Best model by held-out test F1 Score: "
            f"{best_model} ({best_f1:.3f})"
        )

else:

    st.warning(
        "Model results not found. Run `python main.py` first."
    )


# ============================================================
# CONFUSION MATRICES
# ============================================================

st.header("Confusion Matrices")

cm1, cm2, cm3 = st.columns(3)

confusion_matrices = [

    (
        cm1,
        "logistic_regression_confusion_matrix.png",
        "Logistic Regression"
    ),

    (
        cm2,
        "knn_confusion_matrix.png",
        "KNN"
    ),

    (
        cm3,
        "decision_tree_confusion_matrix.png",
        "Decision Tree"
    ),
]


for column, filename, caption in confusion_matrices:

    path = OUT / filename

    if path.exists():

        with column:

            st.image(
                str(path),
                caption=caption,
                use_container_width=True
            )


st.caption(
    "Confusion matrices show correct and incorrect predictions "
    "for UP and DOWN/SAME classes."
)


# ============================================================
# SAVED EDA VISUALISATIONS
# ============================================================

st.header("Exploratory Data Analysis")


# ============================================================
# HISTOGRAM + SCATTER
# ============================================================

eda1, eda2 = st.columns(2)

histogram = OUT / "daily_return_histogram.png"

scatter = OUT / "volume_vs_return_scatter.png"

if histogram.exists():

    with eda1:

        st.subheader("10. Daily Return Distribution")

        st.image(
            str(histogram),
            use_container_width=True
        )

        st.caption(
            "Shows how frequently different daily return values occur."
        )


if scatter.exists():

    with eda2:

        st.subheader("11. Volume vs Daily Return")

        st.image(
            str(scatter),
            use_container_width=True
        )

        st.caption(
            "Examines whether trading volume appears related "
            "to daily stock returns."
        )


# ============================================================
# CORRELATION + RECORD COUNT
# ============================================================

eda3, eda4 = st.columns(2)

correlation = OUT / "correlation_heatmap.png"

records = OUT / "records_per_stock_bar.png"

if correlation.exists():

    with eda3:

        st.subheader("12. Correlation Heatmap")

        st.image(
            str(correlation),
            use_container_width=True
        )

        st.caption(
            "Shows the strength and direction of relationships "
            "between numerical variables."
        )


if records.exists():

    with eda4:

        st.subheader("13. Records per Stock")

        st.image(
            str(records),
            use_container_width=True
        )

        st.caption(
            "Compares the number of observations available "
            "for each selected stock."
        )


# ============================================================
# DATA QUALITY
# ============================================================

st.header("Data Quality")

quality_path = OUT / "data_quality_report.csv"
summary_path = OUT / "cleaning_summary.csv"

if quality_path.exists():

    st.subheader("Column-Level Data Quality")

    quality = pd.read_csv(quality_path)

    st.dataframe(
        quality,
        use_container_width=True
    )


if summary_path.exists():

    st.subheader("Cleaning Summary")

    summary = pd.read_csv(summary_path)

    st.dataframe(
        summary,
        use_container_width=True
    )


# ============================================================
# PROCESSED DATA
# ============================================================

st.header("Processed Dataset")

st.write(
    f"Displaying processed observations for **{selected_stock}**."
)

st.dataframe(
    stock_data,
    use_container_width=True
)


# ============================================================
# DISCLAIMER
# ============================================================

st.warning(
    "Academic project only — not investment advice. "
    "Historical patterns do not guarantee future market performance. "
    "The project uses Yahoo Finance data through yfinance, "
    "which is not an official NSE data feed."
)