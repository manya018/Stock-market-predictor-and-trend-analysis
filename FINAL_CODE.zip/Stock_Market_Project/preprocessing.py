"""Data quality assessment, cleaning and feature engineering."""

from pathlib import Path

import numpy as np
import pandas as pd


# ---------------------------------------------------------
# PATHS
# ---------------------------------------------------------

DATA_DIR = Path("data")
OUTPUT_DIR = Path("outputs")


# ---------------------------------------------------------
# FEATURES USED BY MACHINE LEARNING
# ---------------------------------------------------------

BASE_FEATURES = [
    "Daily_Return",
    "Price_Range",
    "MA_5",
    "MA_10",
    "Previous_Return",
    "Volume_Change",
    "Volatility_5",
]


# ---------------------------------------------------------
# DATA QUALITY ASSESSMENT
# ---------------------------------------------------------

def assess_data_quality(df: pd.DataFrame) -> pd.DataFrame:

    """Generate data-quality reports before cleaning."""

    OUTPUT_DIR.mkdir(exist_ok=True)

    report = pd.DataFrame({

        "Column": df.columns,

        "Data_Type": [
            str(df[c].dtype)
            for c in df.columns
        ],

        "Missing_Values": [
            int(df[c].isna().sum())
            for c in df.columns
        ],

        "Missing_Percent": [
            round(float(df[c].isna().mean() * 100), 2)
            for c in df.columns
        ],

        "Unique_Values": [
            int(df[c].nunique(dropna=True))
            for c in df.columns
        ],
    })

    report.to_csv(
        OUTPUT_DIR / "data_quality_report.csv",
        index=False
    )

    summary = pd.DataFrame([{

        "Rows_Before_Cleaning": len(df),

        "Columns": len(df.columns),

        "Duplicate_Rows": int(
            df.duplicated().sum()
        ),

        "Stocks": (
            int(df["Stock"].nunique())
            if "Stock" in df
            else 0
        ),

        "Earliest_Date": str(
            pd.to_datetime(
                df["Date"]
            ).min().date()
        ),

        "Latest_Date": str(
            pd.to_datetime(
                df["Date"]
            ).max().date()
        ),

    }])

    summary.to_csv(
        OUTPUT_DIR / "data_quality_summary.csv",
        index=False
    )

    return report


# ---------------------------------------------------------
# PREPROCESSING
# ---------------------------------------------------------

def preprocess_data():

    source = DATA_DIR / "stock_data.csv"

    if not source.exists():

        raise FileNotFoundError(
            "data/stock_data.csv not found. "
            "Place your dataset inside the data folder."
        )

    print("\nReading dataset from:")
    print(source)

    df = pd.read_csv(source)

    # -----------------------------------------------------
    # REQUIRED COLUMNS
    # -----------------------------------------------------

    required = [
        "Date",
        "Stock",
        "Open",
        "High",
        "Low",
        "Close",
        "Volume"
    ]

    missing_columns = [
        column
        for column in required
        if column not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            f"Dataset is missing required columns: "
            f"{missing_columns}"
        )

    # -----------------------------------------------------
    # DATA TYPES
    # -----------------------------------------------------

    df["Date"] = pd.to_datetime(
        df["Date"],
        errors="coerce"
    )

    numeric_columns = [
        "Open",
        "High",
        "Low",
        "Close",
        "Volume"
    ]

    for column in numeric_columns:

        df[column] = pd.to_numeric(
            df[column],
            errors="coerce"
        )

    # -----------------------------------------------------
    # DATA QUALITY REPORT
    # -----------------------------------------------------

    assess_data_quality(df)

    rows_before = len(df)

    # -----------------------------------------------------
    # CLEANING
    # -----------------------------------------------------

    df = df.drop_duplicates()

    df = df.dropna(
        subset=[
            "Date",
            "Stock",
            "Open",
            "High",
            "Low",
            "Close",
            "Volume"
        ]
    )

    # Remove invalid price/volume records

    df = df[
        (df["Open"] > 0)
        & (df["High"] > 0)
        & (df["Low"] > 0)
        & (df["Close"] > 0)
        & (df["Volume"] >= 0)
    ]

    # Sort each stock chronologically

    df = df.sort_values(
        ["Stock", "Date"]
    ).reset_index(drop=True)

    # -----------------------------------------------------
    # FEATURE ENGINEERING
    # -----------------------------------------------------

    grouped = df.groupby(
        "Stock",
        group_keys=False
    )

    # Daily percentage return

    df["Daily_Return"] = (
        grouped["Close"]
        .pct_change()
    )

    # Difference between daily high and low

    df["Price_Range"] = (
        df["High"] - df["Low"]
    )

    # 5-session moving average

    df["MA_5"] = grouped[
        "Close"
    ].transform(
        lambda s:
        s.rolling(
            5,
            min_periods=5
        ).mean()
    )

    # 10-session moving average

    df["MA_10"] = grouped[
        "Close"
    ].transform(
        lambda s:
        s.rolling(
            10,
            min_periods=10
        ).mean()
    )

    # Previous session return

    df["Previous_Return"] = (
        df.groupby("Stock")[
            "Daily_Return"
        ].shift(1)
    )

    # Percentage change in volume

    df["Volume_Change"] = (
        grouped["Volume"]
        .pct_change()
    )

    # Five-session volatility

    df["Volatility_5"] = (
        df.groupby("Stock")[
            "Daily_Return"
        ].transform(
            lambda s:
            s.rolling(
                5,
                min_periods=5
            ).std()
        )
    )

    # -----------------------------------------------------
    # TARGET VARIABLE
    # -----------------------------------------------------

    # Closing price of next trading session

    df["Next_Close"] = (
        grouped["Close"]
        .shift(-1)
    )

    # Last observation of every stock has no next close

    df = df.dropna(
        subset=["Next_Close"]
    )

    # Binary classification:
    # 1 = UP
    # 0 = DOWN or SAME

    df["Target"] = (
        df["Next_Close"]
        > df["Close"]
    ).astype(int)

    # -----------------------------------------------------
    # REMOVE INVALID DERIVED VALUES
    # -----------------------------------------------------

    df = df.replace(
        [np.inf, -np.inf],
        np.nan
    )

    df = df.dropna(
        subset=BASE_FEATURES + ["Target"]
    )

    # Final chronological ordering

    df = df.sort_values(
        ["Date", "Stock"]
    ).reset_index(drop=True)

    # -----------------------------------------------------
    # SAVE PROCESSED DATA
    # -----------------------------------------------------

    DATA_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

    df.to_csv(
        DATA_DIR / "processed_stock_data.csv",
        index=False
    )

    # One-hot encoded version for inspection

    encoded = pd.get_dummies(
        df,
        columns=["Stock"],
        drop_first=True,
        dtype=int
    )

    encoded.to_csv(
        DATA_DIR / "model_data.csv",
        index=False
    )

    # -----------------------------------------------------
    # CLEANING SUMMARY
    # -----------------------------------------------------

    cleaning_summary = pd.DataFrame([{

        "Rows_Before_Cleaning":
            rows_before,

        "Rows_After_Feature_Engineering":
            len(df),

        "Rows_Removed":
            rows_before - len(df),

        "Stocks_Retained":
            df["Stock"].nunique(),

        "Start_Date":
            df["Date"].min().date(),

        "End_Date":
            df["Date"].max().date(),

        "UP_Class_Count":
            int(
                (df["Target"] == 1).sum()
            ),

        "DOWN_OR_SAME_Class_Count":
            int(
                (df["Target"] == 0).sum()
            ),

    }])

    cleaning_summary.to_csv(
        OUTPUT_DIR / "cleaning_summary.csv",
        index=False
    )

    # -----------------------------------------------------
    # TERMINAL OUTPUT
    # -----------------------------------------------------

    print("\nPreprocessing completed.")

    print(
        "Processed dataset shape:",
        df.shape
    )

    print(
        "\nDataset date range:",
        df["Date"].min().date(),
        "to",
        df["Date"].max().date()
    )

    print(
        "\nStocks:",
        df["Stock"].unique()
    )

    print(
        "\nSelected features:",
        BASE_FEATURES
    )

    print(
        "\nTarget distribution:"
    )

    print(
        df["Target"].value_counts()
    )

    return df


if __name__ == "__main__":

    preprocess_data()